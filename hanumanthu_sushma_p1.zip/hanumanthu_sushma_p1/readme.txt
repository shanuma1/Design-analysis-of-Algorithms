C++
make


To compile, type -
make

To run the code, use this command -
./main -m market-price-list.txt -p price-list.txt

it will produce an `output.txt` file which contains the output
