Run 'make' to compile and run the code in command line.
The program code is written using C++ Language in Linux Environment.
The program implements Kruskal's and Prim's algorithm.
